Included libraries: 

csv
operator
pandas
apyori

To run script:
    *in VS Code terminal execute: python final.py
    newinput.txt will be created and used as a csv file
    output.txt will be created and contain the results