Lindsay Allen - SID#11493077
CPTS 315 - PA#2


Required Libaries:

pandas
csv


File List:

main.py
movie.py
movies.csv
ratings.csv


To Run Program:

python ./main.py